import React from 'react'

import Banner from '../components/Banner'

import BannerBg from '../assets/resources-bg.webp'

const Resources = () => {
  return (
    <main>
        <Banner 
            title="CHRISTINA ELLENBERG," 
            subTitle="MS, RD, LDN, CSCS" 
            underLine="Sustainable change," 
            paragraph="one bite at a time." 
            btnTitle="BOOK A FREE DISCOVERY CALL" 
            btnURL="#"
            imgUrl={BannerBg}
        />
    </main>
  )
}

export default Resources