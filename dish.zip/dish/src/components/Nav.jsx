import React, { useState } from 'react'
import Logo from '../assets/logo.webp'
import { Link } from 'react-router'
import NavLinks from './NavLinks'

const Nav = () => {

    const [open, setOpen] = useState(false)

    const handleOpen = ()=>{
        setOpen(!open)
    }

  return (
    <div className='flex justify-center absolute top-0 right-0 left-0 z-[9999]'>

        <div className="container flex gap-10 items-center justify-between pt-[50px] pb-[50px]">
            
            {/* Brand  */}
            <Link to="/" className="w-[140px] h-[140px]">
                <img src={Logo} alt="brand-logo" className='w-full h-full' />
            </Link>
            {/* Desktop Nav */}
            <nav className='hidden lg:flex justify-between flex-1'>

                <NavLinks responsive="flex-row" />
                

                <div className="right-nav flex gap-5 items-center">
                    <ul className="social-lists flex gap-2">
                        <li className="social-list">
                            <Link to="#" className='social-link w-[20px] h-[20px]'>
                                <svg fill="#ffffff" height="20px" width="20px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="-337 273 123.5 256" xml:space="preserve" stroke="#ffffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M-260.9,327.8c0-10.3,9.2-14,19.5-14c10.3,0,21.3,3.2,21.3,3.2l6.6-39.2c0,0-14-4.8-47.4-4.8c-20.5,0-32.4,7.8-41.1,19.3 c-8.2,10.9-8.5,28.4-8.5,39.7v25.7H-337V396h26.5v133h49.6V396h39.3l2.9-38.3h-42.2V327.8z"></path> </g></svg>
                            </Link>
                        </li>
                    </ul>

                    <Link to="#" className='bg-[var(--primary-btn-bg)] p-5 text-white font-semibold text-xs'>                        
                        BOOK A FREE DISCOVERY CALL                    
                    </Link>
                </div>

            </nav>
            {/* Mobile Nav  */}
            <div className="flex lg:hidden mob-nav">
                <div className="menu-btn cursor-pointer" onClick={handleOpen}>
                    <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M4 18L20 18" stroke="#ffffff" stroke-width="2" stroke-linecap="round"></path> <path d="M4 12L20 12" stroke="#ffffff" stroke-width="2" stroke-linecap="round"></path> <path d="M4 6L20 6" stroke="#ffffff" stroke-width="2" stroke-linecap="round"></path> </g></svg>
                </div>

            </div>

        </div>

        <div className={ `${ open ? 'translate-x-0' : 'translate-x-full' } z-[9999] bg-stone-900 mob-lists absolute top-0 left-0 right-0 w-full h-screen p-4 flex flex-col gap-10 transform transition-transform duration-300 ease-in-out`}>
            <div className="close-btn cursor-pointer" onClick={handleOpen}>
                <svg viewBox="0 0 24 24" width="20px" height="20px" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M20.7457 3.32851C20.3552 2.93798 19.722 2.93798 19.3315 3.32851L12.0371 10.6229L4.74275 3.32851C4.35223 2.93798 3.71906 2.93798 3.32854 3.32851C2.93801 3.71903 2.93801 4.3522 3.32854 4.74272L10.6229 12.0371L3.32856 19.3314C2.93803 19.722 2.93803 20.3551 3.32856 20.7457C3.71908 21.1362 4.35225 21.1362 4.74277 20.7457L12.0371 13.4513L19.3315 20.7457C19.722 21.1362 20.3552 21.1362 20.7457 20.7457C21.1362 20.3551 21.1362 19.722 20.7457 19.3315L13.4513 12.0371L20.7457 4.74272C21.1362 4.3522 21.1362 3.71903 20.7457 3.32851Z" fill="#ffffff"></path> </g></svg>
            </div>

            <NavLinks responsive='flex-col' onLinkClick={handleOpen}/>

            <div className="right-nav flex flex-col gap-5 items-center">
                <ul className="social-lists flex gap-2">
                    <li className="social-list">
                        <Link to="#" className='social-link w-[20px] h-[20px]'>
                            <svg fill="#ffffff" height="20px" width="20px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="-337 273 123.5 256" xml:space="preserve" stroke="#ffffff"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M-260.9,327.8c0-10.3,9.2-14,19.5-14c10.3,0,21.3,3.2,21.3,3.2l6.6-39.2c0,0-14-4.8-47.4-4.8c-20.5,0-32.4,7.8-41.1,19.3 c-8.2,10.9-8.5,28.4-8.5,39.7v25.7H-337V396h26.5v133h49.6V396h39.3l2.9-38.3h-42.2V327.8z"></path> </g></svg>
                        </Link>
                    </li>
                </ul>

                <Link to="#" className='bg-[var(--primary-btn-bg)] p-5 text-white font-semibold text-xs'>                        
                    BOOK A FREE DISCOVERY CALL                    
                </Link>
            </div>

        </div>

    </div>
  )
}

export default Nav