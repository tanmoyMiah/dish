import React from 'react'
import { Link } from 'react-router-dom'

const Banner = ({title, subTitle, underLine, paragraph, btnTitle, btnURL, imgUrl}) => {
  return (
    <section className="section-banner home-banner flex items-center justify-center" style={{ backgroundImage: `url(${imgUrl})` }}>

        <div className="container content flex flex-col gap-20">

            <div className="content-wrapper">
                <h1 className='font-bold text-white text-2xl md:text-3xl lg:text-5xl leading-[1.5em]'>{title}<br></br>
                    <span className='font-medium'>{subTitle}</span>
                </h1>
                <h2 className='text-xl md:text-2xl lg:text-3xl font-normal text-white'><span className='ziggy-line'>{underLine}</span> {paragraph}</h2>
            </div>

            <div className="btn-wrapper">
                <Link to={btnURL} className='bg-[var(--primary-btn-bg)] p-5 text-white font-semibold text-xs'>                        
                    {btnTitle}             
                </Link>
            </div>
        </div>

    </section>
  )
}

export default Banner