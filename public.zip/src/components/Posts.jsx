import React from 'react'
import Post from './Post'

import PostImg1 from '../assets/roberta-sorge-uOBApnN_K7w-unsplash+(1).webp'

const postsArr = [
    {
        title: "Should You Be Worried About Seed Oils?",
        img: PostImg1,
        date: "Jul 11, 2025",
        desc: "Should You Be Worried About Seed Oils?",
        link: "#"
    },
    {
        title: "Should You Be Worried About Seed Oils?",
        img: PostImg1,
        date: "Jul 11, 2025",
        desc: "Should You Be Worried About Seed Oils?",
        link: "#"
    },
    {
        title: "Should You Be Worried About Seed Oils?",
        img: PostImg1,
        date: "Jul 11, 2025",
        desc: "Should You Be Worried About Seed Oils?",
        link: "#"
    },
]

const Posts = () => {
  return (
    <div className='grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10'>
        {
            postsArr.map( (post, idx) => (
                <Post key={idx} title={post.title} img={post.img} date={post.date} desc={post.desc} link={post.link} />
            ) )
        }
    </div>
  )
}

export default Posts