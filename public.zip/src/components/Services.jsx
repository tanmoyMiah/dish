import React from 'react'
import Service from './Service'

const Services = ({servicesArr, responsive}) => {
  return (
    <div className={`grid w-full gap-10 ${responsive}`}>
        {/* Service  */}

        {
            servicesArr.map( service => (
                <Service cover={service.cover} title={service.title} desc={service.desc} />
            ) )
        }

        
    </div>
  )
}

export default Services