import React from 'react'
import { Link } from 'react-router-dom'

const Service = ({cover, title, desc}) => {
  return (
    <div className="flex flex-col w-full items-center gap-5 p-5 bg-[#789370] text-white">
        <img src={cover} className="w-full h-2/3 min-h-[220px] object-cover" alt="" />
        <h2 className="title font-semibold sm:text-[16px]">{title}</h2>
        <p className="description text-[14px] text-center">{desc}</p>
        <Link to="#" className='pl-5 pr-5 pt-2 pb-2 bg-white text-[#789370] font-bold text-[12px] uppercase'>Learn More</Link>
    </div>
  )
}

export default Service