import React from 'react'
import { Link } from 'react-router-dom'

const Footer = () => {
  return (
    <footer className='pt-[80px] pb-[80px]'>
        <div className="container m-auto grid sm:grid-cols-1 lg:grid-cols-2">
            <div className="left">
                <h1 className='font-bold text-2xl'>DIETITIAN DISH, LLC</h1>
                <h2 className='font-semibold text-xl'>All foods can fit!</h2>

                <p className='font-[14px] mt-10'>Registered Dietitian & Nutrition Coach in Georgia & North Carolina</p>
            </div>
            <div className="right flex justify-center">
                <ul className='flex gap-5 flex-col'>
                    <li>
                        <Link to="/" className='text-[16px] text-green-500 underline font-semibold'>Home</Link>
                    </li>
                    <li>
                        <Link to="/about" className='text-[16px] text-green-500 underline font-semibold'>About Us</Link>
                    </li>
                    <li>
                        <Link to="/services" className='text-[16px] text-green-500 underline font-semibold'>Services</Link>
                    </li>
                    <li>
                        <Link to="/contact" className='text-[16px] text-green-500 underline font-semibold'>Contact</Link>
                    </li>
                </ul>
            </div>
        </div>
    </footer>
  )
}

export default Footer