import React from 'react'

const TopEdgeWav = ({bgColor, strokeColor}) => {
  return (

        <svg
            className="absolute top-0 left-0 w-full"
            viewBox="0 0 1440 150"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* White fill without stroke */}
            <path
              fill={bgColor}
              d="M0,50 C300,150 1140,-50 1440,50 L1440,0 L0,0 Z"
            ></path>

            {/* Stroke only along the bottom curve */}
            <path
              fill="none"
              stroke={strokeColor}
              strokeWidth="3"
              d="M0,50 C300,150 1140,-50 1440,50"
            ></path>
        </svg>

  )
}

export default TopEdgeWav