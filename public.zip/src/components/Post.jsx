import React from 'react'
import { Link } from 'react-router'

const Post = ({img, title, desc, date, link}) => {
  return (
    <div className="flex flex-col gap-2 p-10">
        <div className="img-wrapper h-2/3 overflow-hidden">
            <img src={img} className='w-full h-full' alt="" />
        </div>

        <h2 className="title font-bold text-xl">{title}</h2>

        <p>{desc}</p>

        <Link to={link}>Read More</Link>

        <p className='text-[12px]'>{date}</p>
    </div>
  )
}

export default Post