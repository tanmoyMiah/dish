import React from 'react'
import NavLink from './NavLink'

const lists = [
    { url: 'about', title: "About Us" },
    { url: 'services', title: "Services" },
    { url: 'resources', title: "Resources" },
    { url: 'contact', title: "Contact" },
]

const NavLinks = ({responsive, onLinkClick }) => {
  return (
    
    <ul className={`nav-lists flex gap-5 ${responsive}`}>
        
        {
            lists.map( (item, index) => ( 
                <NavLink key={index} url={item.url} title={item.title} onClick={onLinkClick}/>
            ) )
        }

    </ul>

    
  )
}

export default NavLinks