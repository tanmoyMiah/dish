import React from 'react'

const BottomEdgeWav = ({ bgColor = '#26312b', strokeColor = '#a52a2a', offsetY = 0 }) => {
  return (
    <svg
      className="absolute bottom-0 left-0 w-full"
      viewBox="0 0 1440 150"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g transform={`translate(0, ${offsetY})`}>
        {/* Fill (area below the rotated curve) */}
        <path
          fill={bgColor}
          d="M0,90
             C360,150 1080,50 1440,100
             L1440,150
             L0,150
             Z"
        />

        {/* Stroke along the curve */}
        <path
          fill="none"
          stroke={strokeColor}
          strokeWidth="3"
          d="M0,90
             C360,150 1080,50 1440,100"
        />
      </g>
    </svg>
  )
}

export default BottomEdgeWav



