import React from 'react'
import { Link } from 'react-router-dom'

const NavLink = ({url, title, onClick}) => {
  return (
    <li className="nav-list" onClick={onClick}>
        
        <Link to={url} className="nav-link text-lg text-white font-semibold">{title}</Link>
    </li>
  )
}

export default NavLink