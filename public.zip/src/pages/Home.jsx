import React from 'react'
import { Link } from 'react-router-dom'
import Banner from '../components/Banner'
import BannerBg from '../assets/home-bg.webp'
import Christine from '../assets/200728_christina006.webp'
import Services from '../components/Services'

import WavyImg from '../assets/wavy.jpg'

import Serv1 from '../assets/image-asset.webp'
import Serv2 from '../assets/image-asset (1).webp'
import Serv3 from '../assets/image-asset (2).webp'
import Serv4 from '../assets/image-asset (3).webp'

const servicesArr = [
    {
        cover: Serv1,
        title: 'ONE-ON-ONE COACHING',
        desc: 'Available in-person or online, I will meet with you to craft a individualized plan to help meet your health and nutrition goals.'
    },
    {
        cover: Serv2,
        title: 'FAMILY NUTRITION SUPPORT',
        desc: 'Take the guesswork out of planning nutritious meals for your family with anything from grocery store tours to family nutrition consulations.'
    },
    {
        cover: Serv3,
        title: 'SPEAKING & MENU CONSULTING',
        desc: 'If you need a speaker for your workplace or group or, if you are a business that needs their menus analyzed, I am here to help!'
    },
    {
        cover: Serv4,
        title: 'MEAL PLANS & RECIPES',
        desc: 'If planning nutritious meals is overwhelming, let me help! I can create easy-to-follow plans that eliminate stress from your busy lifestyle.'
    }
]

const Home = () => {
  return (
    <main>
        <Banner 
            title="CHRISTINA ELLENBERG," 
            subTitle="MS, RD, LDN, CSCS" 
            underLine="Sustainable change," 
            paragraph="one bite at a time." 
            btnTitle="BOOK A FREE DISCOVERY CALL" 
            btnURL="#"
            imgUrl={BannerBg}
        />

        <section className='bg-[#E5DFD8] pt-[100px] pb-[100px]'>

          <div className="container m-auto">
            <div className="grid sm:grid-cols-1 md:grid-cols-2 items-center gap-10">

              <div className="flex flex-col items-start gap-5 w-full">
                <h1 className='sm:text-2xl md:text-3xl lg:text-6xl font-bold text-orange-500'>All foods can fit!</h1>

                <h2 className='sm:text-xl md:text-2xl lg:text-3xl font-semibold'>A BALANCED APPROACH TO NUTRITION</h2>

                <p>As an experienced Registered Dietitian Nutritionist (RDN) and Strength and Conditioning Specialist (CSCS) in Atlanta, I understand that when it comes to a healthy diet, there is no one-size-fits-all approach. However, one principle that <b>I firmly believe in is that all foods can fit into a well-rounded and balanced eating plan.</b></p>

                <p>Whether you are looking for help with <b>sports nutrition, weight management, metabolic health/chronic disease management, or intuitive eating…</b> I can help you find solutions unique for YOU!</p>
                

                <p>Healthy living and eating shouldn’t be based simply on a number on a scale, so I will work with you <b>one-on-one to develop a personalized nutrition plan that meets your lifestyle and goals!</b></p>

                <Link to="/about" className="bg-[var(--primary-btn-bg)] p-5 text-white font-semibold text-xs min-w-[200px] flex justify-center items-center">ABOUT MY APPROACH</Link>

              </div>

              <div className="w-full">
                  <div className="img-wrapper w-full flex justify-center">
                    <img src={Christine} className='sm:w-full md:w-[50%] lg:w-[50%]' alt="Christine" />
                  </div>
              </div>

            </div>
          </div>

        </section>

        <section className='pt-[100px] pb-[100px]'>
            <div className="container mx-auto">

              <h1 className='text-center sm:text-4xl lg:text-6xl font-semibold mb-10'>Services</h1>

              <Services servicesArr={servicesArr} responsive="sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4" />

              <div className="btn-wrapper mt-10 flex items-center w-full justify-center">
                <Link to="#" className='inline-block text-[16px] p-5 text-center bg-[hsla(126.67,7.69%,22.94%,1)] font-semibold text-white'>EXPLORE SERVICES AND PRICING</Link>
              </div>


            </div>
        </section>

        {/* Testimonial Section  */}

        <section className='p-0 m-0 relative h-screen w-screen flex justify-center items-center'>
            <img src={WavyImg} className=' absolute top-0 left-0 right-0 bottom-0 w-full h-full object-cover' alt="" />

            <div className="absolute top-0 left-0 right-0 bottom-0 w-full h-full" style={{ backgroundColor: "rgba(0, 0, 0, 0.5)"}}></div>

            <div className="container flex items-center flex-col m-auto relative testimonial z-[999] gap-10">

              <div className="content-wrapper">
                <h2 className="title sm:text-xl md:text-2xl lg:text-3xl text-gray-200 font-semibold">“Christina is wonderful! I have also been so overwhelmed with all of the nutrition information out there. I tried numerous diets and would lose the weight and then gain it back. Christina takes a very unique approach and explained to me the why along the way. I still am able to eat the foods I enjoy and not only lost 7 pounds, but my energy levels have increased. I cannot recommend Christina enough.”</h2>

                <p className="author font-semibold text-[16px] text-gray-200 mt-5">-Kim C.</p>
              </div>

                <Link to="#" className='flex items-center justify-center bg-[#789370] hover:bg-[#7893709e] transition-all ease-linear p-5 lg:min-h-[80px] lg:min-w-[450px] text-white text-[14px] font-bold'>SEE WHAT MY CLIENTS HAVE TO SAY</Link>
            </div>

            {/* Top wave with bottom stroke only */}
          <svg
            className="absolute top-0 left-0 w-full"
            viewBox="0 0 1440 150"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* White fill without stroke */}
            <path
              fill="white"
              d="M0,50 C300,150 1140,-50 1440,50 L1440,0 L0,0 Z"
            ></path>

            {/* Stroke only along the bottom curve */}
            <path
              fill="none"
              stroke="#a52a2a"
              strokeWidth="3"
              d="M0,50 C300,150 1140,-50 1440,50"
            ></path>
          </svg>

          {/* Bottom wave */}
          <svg
            className="absolute bottom-0 left-0 w-full"
            viewBox="0 0 1440 150"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Fill */}
            <path
              fill="#789370"
              d="M0,100 
                C360,0 1080,200 1440,100 
                L1440,150 
                L0,150 
                Z"
            ></path>

            {/* Stroke only along the top curve */}
            <path
              fill="none"
              stroke="#a52a2a"
              strokeWidth="3"
              d="M0,100 
                C360,0 1080,200 1440,100"
            ></path>
          </svg>

        </section>

        <section className='pt-[100px] pb-[100px] bg-[#789370]'>
          <div className="container m-auto flex flex-col items-center gap-5 text-white">

            <h2 className='sm:text-2xl lg:text-3xl'>I can’t wait to help you meet your goals!</h2>

            <h1 className="underline sm:text-2xl lg:text-4xl font-bold">It is possible.</h1>

            <Link to="#" className='px-10 py-5 bg-orange-800 text-xl font-bold'>Contact Christina</Link>

            <p className="underline">Or explore my service options HERE.</p>

          </div>
        </section>

    </main>
  )
}

export default Home