import React from 'react'

import Banner from '../components/Banner'

import BannerBg from '../assets/resources-bg.webp'
import Posts from '../components/Posts'
import BottomEdgeWav from '../components/BottomEdgeWav'
import { Link } from 'react-router-dom'
import TopEdgeWav from '../components/TopEdgeWav'

import Img from '../assets/cowomen-QziaoZM0M44-unsplash.jpg'

const Resources = () => {
  return (
    <main>
        <Banner 
            title="CHRISTINA ELLENBERG," 
            subTitle="MS, RD, LDN, CSCS" 
            underLine="Sustainable change," 
            paragraph="one bite at a time." 
            btnTitle="BOOK A FREE DISCOVERY CALL" 
            btnURL="#"
            imgUrl={BannerBg}
        />

        <section className='pb-[100px] pt-[100px] bg-[#E5DFD8]'>
            <div className="container m-auto">
                <h2 className="title text-6xl font-semibold text-center">Get the Dish</h2>
                <p className='text-center mb-20'>Explore my blog for tips on healthy eating, living well, recipes, and more!</p>

                <Posts />
            </div>
        </section>

        <section className='pt-[100px] pb-[100px] relative'>

            <div className="container m-auto pt-[100px] pb-[100px] flex flex-col gap-5 relative z-[9999]">


                <h1 className="title sm:text-xl md:text-3xl lg:text-5xl text-white text-center">These are a few of my favorite things.</h1>
                <p className='text-center text-white'>From the Intuitive Eating Handbook to my favorite protein powder, check out my Amazon storefront for some products I recommend to clients on a daily basis.</p>

                <div className="btn-wrapper flex justify-center">
                  <Link to="#" className='flex items-center justify-center bg-[#789370] hover:bg-[#7893709e] transition-all ease-linear p-5 lg:min-h-[80px] lg:min-w-[450px] text-white text-[14px] font-bold'>SHOPE HERE</Link>
                </div>

            </div>

            
            <img src={Img} alt="" className='w-full h-full absolute top-0 bottom-0 left-0 right-0 object-cover object-top' />
            <div className="full-shadow"></div>
            <TopEdgeWav bgColor="#E5DFD8" strokeColor="#8E3535" />
            <BottomEdgeWav bgColor="#ffffff" strokeColor="#8E3535" />
            


        </section>

    </main>
  )
}

export default Resources