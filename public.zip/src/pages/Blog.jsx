import React from 'react'

const Blog = () => {
  return (
    <main className='bg-stone-400 pt-[300px]'>

      <div className="container">

      </div>

    </main>
  )
}

export default Blog