import React from 'react'
import Banner from '../components/Banner'
import Services from '../components/Services'

import BannerBg from '../assets/services-bg.webp'
import { Link } from 'react-router-dom'

import imgAsset from '../assets/image-asset (4).webp'

import Serv1 from '../assets/image-asset.webp'
import Serv2 from '../assets/image-asset (1).webp'
import Serv3 from '../assets/image-asset (2).webp'
import Serv4 from '../assets/image-asset (3).webp'
import BottomEdgeWav from '../components/BottomEdgeWav'

const servicesArr = [
    {
        cover: Serv1,
        title: 'ONE-ON-ONE COACHING',
        desc: 'Available in-person or online, I will meet with you to craft a individualized plan to help meet your health and nutrition goals.'
    },
    {
        cover: Serv2,
        title: 'FAMILY NUTRITION SUPPORT',
        desc: 'Take the guesswork out of planning nutritious meals for your family with anything from grocery store tours to family nutrition consulations.'
    },
    {
        cover: Serv3,
        title: 'SPEAKING & MENU CONSULTING',
        desc: 'If you need a speaker for your workplace or group or, if you are a business that needs their menus analyzed, I am here to help!'
    },
    {
        cover: Serv4,
        title: 'MEAL PLANS & RECIPES',
        desc: 'If planning nutritious meals is overwhelming, let me help! I can create easy-to-follow plans that eliminate stress from your busy lifestyle.'
    }
]

const ServicesPage = () => {
  return (
    <main>
        <Banner 
            title="CHRISTINA ELLENBERG," 
            subTitle="MS, RD, LDN, CSCS" 
            underLine="Sustainable change," 
            paragraph="one bite at a time." 
            btnTitle="BOOK A FREE DISCOVERY CALL" 
            btnURL="#"
            imgUrl={BannerBg}
        />

        <section className='pt-[100px] pb-[100px] bg-[#E5DFD8]'>
            <div className="container m-auto">

                <h2 className='text-center font-bold sm:text-2xl md:text-4xl lg:text-5xl font-normal mb-10'>Your goals are <span className='ziggy-line'>achievable</span>. Let’s get started!</h2>

                <div className="grid sm:grid-cols-1 md:grid-cols-3 gap-10">

                  <div className="img-wrapper flex items-center">
                      <img src={imgAsset} className='h-3/4' alt="" />
                  </div>

                  <div className="col-span-2 flex flex-col items-start justify-center gap-10">

                      <div className="content-wrapper">

                        <p className='mb-5'>Whether you are looking for one-on-one nutrition counseling, family nutrition advice, or just need some meal plans, the best place to begin is with my <b>free 15-minute discovery call!</b></p>

                        <p className='mb-5'>On this call, I will learn more about you and your specific needs, tell you a little more about my services and my approach and how I can help, and you have a chance to ask me any additional questions.</p>

                        <p>Based on what you’re looking for, I will make recommendations for optional next steps!</p>

                      </div>

                      <div className="btn-wrapper">
                          <Link to="#" className='inline-block text-[16px] p-5 text-center bg-[hsla(126.67,7.69%,22.94%,1)] font-semibold text-white'>BOOK a Discovery Call</Link>
                      </div>

                  </div>

                </div>

            </div>
        </section>

        <section className='pt-[100px] pb-[100px]'>

          <div className="container m-auto">
              
              <h1 className='text-center sm:text-4xl lg:text-6xl font-semibold mb-10'>Services</h1>

              <Services servicesArr={servicesArr} responsive="sm:grid-cols-1 lg:grid-cols-2 "/>

          </div>

        </section>

        <section className='pt-[100px] pb-[100px] bg-[#8E3535] relative'>

            <div className="container m-auto">
                <h1 className="title sm:text-xl md:text-3xl lg:text-5xl text-white text-center">Things I Can Help With</h1>

                <div className="grid mt-20 mb-20 sm:grid-cols-1 md:grid-cols-2">
                      <div className="col flex flex-col gap-2 items-center text-xl font-semibold text-white">

                          <p>Sports Nutrition</p>
                          <p>Intuitive Eating</p>
                          <p>Weight Management</p>
                          <p>Chronic Disease Management</p>
                          <p>High Blood Pressure</p>

                      </div>
                      <div className="col flex flex-col gap-2 items-center text-xl font-semibold text-white">
                          <p>Sports Nutrition</p>
                          <p>Intuitive Eating</p>
                          <p>Weight Management</p>
                          <p>Chronic Disease Management</p>
                          <p>High Blood Pressure</p>
                      </div>
                </div>

                <p className='text-center text-white text-xl mt-10 pb-20'><b>Don’t see something you’re looking for?</b> Reach out to me <Link className='underline'>HERE</Link> to see if I can help.</p>  
            </div>

            <BottomEdgeWav bgColor="#ffffff" strokeColor="#789370" />

        </section>


    </main>
  )
}

export default ServicesPage